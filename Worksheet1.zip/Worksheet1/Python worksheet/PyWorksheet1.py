#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Question 11 - Finding the factorial of a number
# Taking input from the user
num = int(input("Enter a number: "))

#Set factorial default to 1
factorial = 1

# check if the number is negative, positive or zero
if num < 0:
   print("Sorry, factorial does not exist for negative numbers")
elif num == 0:
   print("The factorial of 0 is 1")
else:
#Running for loop from 1 upto entered number
   for i in range(1,num + 1):
       factorial = factorial*i
   print("The factorial of",num,"is",factorial)


# In[2]:


#Question 12 - python program to find whether a number is prime or composite
# Taking input from the user
num = int(input("Enter the integer number: "))

# If given number is greater than 1
if num > 1:
 
    # Iterate from 2 to n / 2
    for i in range(2, int(num/2)+1):
 
        # If num is divisible by any number between
        # 2 and n / 2, it is not prime
        if (num % i) == 0:
            print(num, "is not a prime number")
            break
    else:
        print(num, "is a prime number")
 
else:
    print(num, "is not a prime number")


# In[3]:


#Question 13 - Check whether a given string is palindrome or not
# function to check string is palindrome or not
def isPalindrome(s):
     
    # Using predefined function to
    # reverse to string print(s)
    rev = ''.join(reversed(s))
 
    # Checking if both string are
    # equal or not
    if (s == rev):
        return True
    return False
 
# main function
s = input("Enter the string: ")
ans = isPalindrome(s)
 
if (ans):
    print("Yes")
else:
    print("No")


# In[4]:


#Question 14 -  Get the third side of right-angled triangle from two given sides
import math

#get the two sides of the triangle
side1 = int(input("Enter the side1: "))
side2 = int(input("Enter the side2: "))

#print the hypotenuse of a right-angled triangle
print("The hypotenues is")
print(math.hypot(side1, side2))


# In[5]:


#Question 15 - print the frequency of each of the characters present in a given string
# USing collections.Counter()
from collections import Counter
  
# initializing string 
given_str = input("Enter the string: ")
  
# using collections.Counter() to get 
# count of each element in string 
res = Counter(given_str)
  
# printing result 
print ("Count of all characters in "+ given_str+" is :\n "
                                           +  str(res))


# In[ ]:




